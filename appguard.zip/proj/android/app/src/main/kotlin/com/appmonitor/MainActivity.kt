package com.appmonitor
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.appmonitor/apps"
    override fun configureFlutterEngine(fe: FlutterEngine) {
        super.configureFlutterEngine(fe)
        MethodChannel(fe.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "getRunningApps" -> result.success(getRunningApps())
                "getInstalledApps" -> result.success(getInstalledApps())
                "openAppSettings" -> { openSettings(call.argument("packageName") ?: ""); result.success(null) }
                else -> result.notImplemented()
            }
        }
    }
    private fun getRunningApps(): List<Map<String,Any>> {
        val apps = mutableListOf<Map<String,Any>>()
        try {
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val stats = um.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now-3600000, now)
            for (s in stats.filter { it.lastTimeUsed > now-3600000 }.sortedByDescending { it.lastTimeUsed }.take(20)) {
                try {
                    val ai = packageManager.getApplicationInfo(s.packageName, 0)
                    apps.add(mapOf("packageName" to s.packageName, "appName" to packageManager.getApplicationLabel(ai).toString(), "isBackground" to ((now-s.lastTimeUsed)>30000)))
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        return apps
    }
    private fun getInstalledApps(): List<Map<String,Any>> {
        val apps = mutableListOf<Map<String,Any>>()
        val pkgs = if (Build.VERSION.SDK_INT >= 33) packageManager.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
                   else @Suppress("DEPRECATION") packageManager.getInstalledApplications(0)
        for (a in pkgs) {
            if (a.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM != 0) continue
            try { apps.add(mapOf("packageName" to a.packageName, "appName" to packageManager.getApplicationLabel(a).toString())) } catch (_: Exception) {}
        }
        return apps
    }
    private fun openSettings(pkg: String) {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = Uri.parse("package:$pkg"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }
}
