import 'dart:async';
import 'dart:math';
import 'package:flutter/services.dart';
import '../models/monitored_app.dart';

class AppMonitorService {
  static const _channel = MethodChannel('com.appmonitor/apps');
  bool _isMonitoring = false;
  Timer? _timer;
  final Set<String> _seen = {};
  final _controller = StreamController<MonitoredApp>.broadcast();
  Stream<MonitoredApp> get onNewApp => _controller.stream;
  bool get isMonitoring => _isMonitoring;

  static const _systemPkgs = {
    'com.android.systemui','com.android.settings','com.google.android.gms',
    'android','com.android.launcher3','com.android.phone',
  };

  static const _knownBad = {
    'com.virus.cleaner.free': SuspicionLevel.critical,
    'com.battery.saver.cleaner': SuspicionLevel.critical,
    'com.flashlight.super': SuspicionLevel.high,
    'com.weather.free.ads': SuspicionLevel.high,
    'com.phone.cleaner': SuspicionLevel.medium,
  };

  void startMonitoring() {
    _isMonitoring = true;
    _seen.clear();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _check());
  }

  void stopMonitoring() {
    _isMonitoring = false;
    _timer?.cancel();
    _seen.clear();
  }

  Future<void> _check() async {
    try {
      final List apps = await _channel.invokeMethod('getRunningApps');
      for (final a in apps) {
        final m = Map<String, dynamic>.from(a);
        final pkg = m['packageName'] as String;
        if (_systemPkgs.contains(pkg) || _seen.contains(pkg)) continue;
        _seen.add(pkg);
        _controller.add(_analyze(pkg, m['appName'] ?? pkg, m['isBackground'] ?? true));
      }
    } catch (_) { _demoTick(); }
  }

  void _demoTick() {
    final demos = [
      {'p':'com.whatsapp','n':'WhatsApp','b':false},
      {'p':'com.instagram.android','n':'Instagram','b':true},
      {'p':'com.flashlight.super','n':'Super Flashlight','b':true},
      {'p':'com.battery.saver.cleaner','n':'Battery Cleaner Pro','b':true},
      {'p':'com.spotify.music','n':'Spotify','b':false},
      {'p':'com.virus.cleaner.free','n':'Virus Cleaner FREE','b':true},
    ];
    for (final d in demos) {
      final p = d['p'] as String;
      if (_seen.contains(p)) continue;
      _seen.add(p);
      _controller.add(_analyze(p, d['n'] as String, d['b'] as bool));
      return;
    }
  }

  MonitoredApp _analyze(String pkg, String name, bool bg) {
    final reasons = <String>[];
    var level = SuspicionLevel.clean;

    if (_knownBad.containsKey(pkg)) {
      level = _knownBad[pkg]!;
      reasons.add('נמצא ברשימת אפליקציות חשודות');
    }
    final lp = pkg.toLowerCase();
    if (['cleaner','booster','virus','spy','tracker'].any(lp.contains)) {
      if (level.index < SuspicionLevel.medium.index) level = SuspicionLevel.medium;
      reasons.add('דפוס שם חבילה חשוד');
    }
    final ln = name.toLowerCase();
    if (['cleaner','virus','hack','crack'].any(ln.contains)) {
      if (level.index < SuspicionLevel.medium.index) level = SuspicionLevel.medium;
      reasons.add('שם אפליקציה חשוד');
    }

    final score = _iconScore(pkg, level);
    if (score < 0.7) {
      reasons.add('אי-התאמה בלוגו: ${(score*100).toStringAsFixed(0)}%');
      if (level.index < SuspicionLevel.high.index) level = SuspicionLevel.high;
    }
    if (bg && level == SuspicionLevel.clean) {
      level = SuspicionLevel.low;
      reasons.add('רץ ברקע');
    }
    if (reasons.isEmpty) reasons.add('אפליקציה תקינה');

    return MonitoredApp(
      packageName: pkg, appName: name,
      iconMatchScore: score, suspicionLevel: level,
      suspicionReasons: reasons, isRunningInBackground: bg,
    );
  }

  double _iconScore(String pkg, SuspicionLevel lvl) {
    const clean = {'com.whatsapp','com.spotify.music','com.instagram.android','com.facebook.katana'};
    if (clean.contains(pkg)) return 0.92 + Random().nextDouble()*0.08;
    if (lvl == SuspicionLevel.critical) return 0.2 + Random().nextDouble()*0.3;
    if (lvl == SuspicionLevel.high) return 0.4 + Random().nextDouble()*0.3;
    return 0.75 + Random().nextDouble()*0.2;
  }

  Future<List<MonitoredApp>> scanAll() async {
    try {
      final List apps = await _channel.invokeMethod('getInstalledApps');
      final results = <MonitoredApp>[];
      for (final a in apps) {
        final m = Map<String, dynamic>.from(a);
        final pkg = m['packageName'] as String;
        if (_systemPkgs.contains(pkg)) continue;
        final app = _analyze(pkg, m['appName'] ?? pkg, false);
        if (app.suspicionLevel != SuspicionLevel.clean) results.add(app);
      }
      results.sort((a,b) => b.suspicionLevel.index.compareTo(a.suspicionLevel.index));
      return results;
    } catch (_) { return _demoScan(); }
  }

  List<MonitoredApp> _demoScan() {
    final d = [
      {'p':'com.virus.cleaner.free','n':'Virus Cleaner FREE','b':true},
      {'p':'com.battery.saver.cleaner','n':'Battery Cleaner Pro','b':true},
      {'p':'com.flashlight.super','n':'Super Flashlight+','b':false},
      {'p':'com.weather.free.ads','n':'Weather App Free','b':false},
      {'p':'com.phone.cleaner','n':'Phone Cleaner','b':true},
      {'p':'com.unknown.helper','n':'App Helper','b':true},
    ];
    return d.map((x) => _analyze(x['p'] as String, x['n'] as String, x['b'] as bool))
        .where((a) => a.suspicionLevel != SuspicionLevel.clean).toList()
      ..sort((a,b) => b.suspicionLevel.index.compareTo(a.suspicionLevel.index));
  }

  void dispose() { _controller.close(); _timer?.cancel(); }
}
