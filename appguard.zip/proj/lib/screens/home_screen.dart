import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/monitored_app.dart';
import '../services/app_monitor_service.dart';
import '../widgets/app_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final _service = AppMonitorService();
  final _apps = <MonitoredApp>[];
  bool _scanning = false;
  late final AnimationController _pulse = AnimationController(vsync:this, duration: const Duration(seconds:1))..repeat(reverse:true);

  @override
  void initState() {
    super.initState();
    _service.onNewApp.listen((app) {
      if (!mounted) return;
      setState(() => _apps.insert(0, app));
      if (app.suspicionLevel != SuspicionLevel.clean) _snack(app);
    });
  }

  void _snack(MonitoredApp app) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    backgroundColor: const Color(0xFF1E1E2E),
    behavior: SnackBarBehavior.floating,
    margin: const EdgeInsets.all(12),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    content: Row(children: [
      Icon(Icons.warning_amber, color: app.suspicionColor),
      const SizedBox(width:10),
      Expanded(child: Text('${app.appName} זוהתה! ${app.suspicionText}', style: const TextStyle(color:Colors.white))),
    ]),
    duration: const Duration(seconds:3),
  ));

  void _start() { setState(() { _apps.clear(); _service.startMonitoring(); }); }
  void _stop() { setState(() => _service.stopMonitoring()); }

  Future<void> _scan() async {
    setState(() => _scanning = true);
    final r = await _service.scanAll();
    setState(() { _apps.clear(); _apps.addAll(r); _scanning = false; });
  }

  Future<void> _openSettings(MonitoredApp app) async {
    try {
      await const MethodChannel('com.appmonitor/apps').invokeMethod('openAppSettings', {'packageName': app.packageName});
    } catch (_) {
      if (!mounted) return;
      showDialog(context: context, builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E2E),
        title: const Text('הגדרות', style: TextStyle(color:Colors.white)),
        content: Text('יפתח הגדרות של ${app.appName}', style: const TextStyle(color:Colors.grey)),
        actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('סגור'))],
      ));
    }
  }

  Future<void> _openStore(MonitoredApp app) async {
    final uri = Uri.parse('https://play.google.com/store/apps/details?id=${app.packageName}');
    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  void dispose() { _service.dispose(); _pulse.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF0D0D1A),
    body: SafeArea(child: Column(children: [
      _header(), _buttons(), _stats(),
      Expanded(child: _list()),
    ])),
  );

  Widget _header() => Padding(
    padding: const EdgeInsets.fromLTRB(20,20,20,10),
    child: Row(children: [
      Container(
        width:48, height:48,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors:[Color(0xFF6C63FF),Color(0xFF3B82F6)]),
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(Icons.security, color:Colors.white, size:26),
      ),
      const SizedBox(width:12),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('AppGuard Monitor', style: TextStyle(color:Colors.white, fontSize:20, fontWeight:FontWeight.bold)),
        Text(_service.isMonitoring ? '🟢 ניטור פעיל' : '⚫ ניטור כבוי',
          style: TextStyle(color: _service.isMonitoring ? Colors.green : Colors.grey, fontSize:12)),
      ]),
      const Spacer(),
      if (_service.isMonitoring) ScaleTransition(
        scale: Tween(begin:0.8, end:1.2).animate(CurvedAnimation(parent:_pulse, curve:Curves.easeInOut)),
        child: Container(width:12, height:12, decoration: const BoxDecoration(color:Colors.green, shape:BoxShape.circle)),
      ),
    ]),
  );

  Widget _buttons() => Padding(
    padding: const EdgeInsets.symmetric(horizontal:16, vertical:8),
    child: Row(children: [
      Expanded(child: _Btn(icon:Icons.play_circle_filled, label:'הפעל ניטור', color: const Color(0xFF4CAF50), onTap: _service.isMonitoring ? null : _start)),
      const SizedBox(width:8),
      Expanded(child: _Btn(icon:Icons.stop_circle, label:'הפסק ניטור', color: const Color(0xFFF44336), onTap: _service.isMonitoring ? _stop : null)),
      const SizedBox(width:8),
      Expanded(child: _Btn(icon:Icons.radar, label:'סרוק', color: const Color(0xFF6C63FF), onTap: _scanning ? null : _scan, loading: _scanning)),
    ]),
  );

  Widget _stats() {
    final counts = <SuspicionLevel,int>{};
    for (final a in _apps) counts[a.suspicionLevel] = (counts[a.suspicionLevel]??0)+1;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal:16, vertical:4),
      padding: const EdgeInsets.symmetric(horizontal:16, vertical:10),
      decoration: BoxDecoration(color: const Color(0xFF1E1E2E), borderRadius: BorderRadius.circular(12)),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
        _Stat('סה"כ', '${_apps.length}', Colors.white),
        _Stat('קריטי', '${counts[SuspicionLevel.critical]??0}', const Color(0xFF9C27B0)),
        _Stat('גבוה', '${counts[SuspicionLevel.high]??0}', const Color(0xFFF44336)),
        _Stat('בינוני', '${counts[SuspicionLevel.medium]??0}', const Color(0xFFFF9800)),
        _Stat('נמוך', '${counts[SuspicionLevel.low]??0}', const Color(0xFF8BC34A)),
      ]),
    );
  }

  Widget _list() {
    if (_apps.isEmpty) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(_service.isMonitoring ? Icons.search : Icons.shield, size:64, color:Colors.grey[700]),
      const SizedBox(height:16),
      Text(_service.isMonitoring ? 'מחפש אפליקציות...' : 'לחץ הפעל ניטור או סרוק',
        style: TextStyle(color:Colors.grey[600], fontSize:14), textAlign: TextAlign.center),
    ]));
    return ListView.builder(
      padding: const EdgeInsets.only(top:8, bottom:20),
      itemCount: _apps.length,
      itemBuilder: (_, i) => AppCard(app:_apps[i], onDelete:()=>_openSettings(_apps[i]), onOpenStore:()=>_openStore(_apps[i])),
    );
  }
}

class _Btn extends StatelessWidget {
  final IconData icon; final String label; final Color color;
  final VoidCallback? onTap; final bool loading;
  const _Btn({required this.icon, required this.label, required this.color, this.onTap, this.loading=false});
  @override
  Widget build(BuildContext context) {
    final off = onTap == null && !loading;
    return GestureDetector(onTap: onTap, child: AnimatedContainer(
      duration: const Duration(milliseconds:200),
      padding: const EdgeInsets.symmetric(vertical:12),
      decoration: BoxDecoration(
        color: off ? const Color(0xFF1A1A2E) : color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: off ? Colors.grey.withOpacity(0.2) : color.withOpacity(0.5), width:1.5),
      ),
      child: Column(children: [
        loading ? SizedBox(width:24, height:24, child: CircularProgressIndicator(strokeWidth:2, color:color))
               : Icon(icon, color: off ? Colors.grey[700] : color, size:26),
        const SizedBox(height:4),
        Text(label, style: TextStyle(color: off ? Colors.grey[700] : color, fontSize:11, fontWeight:FontWeight.w600), textAlign: TextAlign.center),
      ]),
    ));
  }
}

class _Stat extends StatelessWidget {
  final String l, v; final Color c;
  const _Stat(this.l, this.v, this.c);
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(v, style: TextStyle(color:c, fontSize:16, fontWeight:FontWeight.bold)),
    Text(l, style: TextStyle(color:Colors.grey[600], fontSize:10)),
  ]);
}
