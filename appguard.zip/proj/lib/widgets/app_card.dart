import 'package:flutter/material.dart';
import '../models/monitored_app.dart';

class AppCard extends StatelessWidget {
  final MonitoredApp app;
  final VoidCallback? onDelete;
  final VoidCallback? onOpenStore;
  const AppCard({super.key, required this.app, this.onDelete, this.onOpenStore});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal:16, vertical:8),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E2E),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: app.suspicionColor.withOpacity(0.5), width:1.5),
        boxShadow: [BoxShadow(color: app.suspicionColor.withOpacity(0.1), blurRadius:12)],
      ),
      child: Column(children: [
        _header(),
        if (app.hasIconMismatch) _iconWarn(),
        _reasons(),
        _actions(),
      ]),
    );
  }

  Widget _header() => Padding(
    padding: const EdgeInsets.all(16),
    child: Row(children: [
      Container(
        width:56, height:56,
        decoration: BoxDecoration(
          color: const Color(0xFF2A2A3E),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: app.suspicionColor.withOpacity(0.4)),
        ),
        child: Center(child: Text(
          app.appName.isNotEmpty ? app.appName[0].toUpperCase() : '?',
          style: TextStyle(color: app.suspicionColor, fontSize:22, fontWeight:FontWeight.bold),
        )),
      ),
      const SizedBox(width:12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(app.appName, style: const TextStyle(color:Colors.white, fontSize:16, fontWeight:FontWeight.bold)),
        const SizedBox(height:2),
        Text(app.packageName, style: TextStyle(color:Colors.grey[500], fontSize:11), overflow: TextOverflow.ellipsis),
        const SizedBox(height:6),
        Row(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal:8, vertical:3),
            decoration: BoxDecoration(
              color: app.suspicionColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: app.suspicionColor.withOpacity(0.5)),
            ),
            child: Text(app.suspicionText, style: TextStyle(color: app.suspicionColor, fontSize:11, fontWeight:FontWeight.bold)),
          ),
          if (app.isRunningInBackground) ...[
            const SizedBox(width:6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal:6, vertical:3),
              decoration: BoxDecoration(color: Colors.orange.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
              child: const Text('רקע', style: TextStyle(color:Colors.orange, fontSize:10)),
            ),
          ],
        ]),
      ])),
    ]),
  );

  Widget _iconWarn() => Container(
    margin: const EdgeInsets.symmetric(horizontal:16),
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: Colors.red.withOpacity(0.1),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: Colors.red.withOpacity(0.4)),
    ),
    child: Row(children: [
      const Icon(Icons.warning_amber_rounded, color:Colors.red, size:18),
      const SizedBox(width:8),
      Expanded(child: Text(
        '⚠️ אי-התאמה בלוגו! רמת דיוק: ${(app.iconMatchScore*100).toStringAsFixed(0)}%',
        style: TextStyle(color:Colors.red[300], fontSize:11),
      )),
    ]),
  );

  Widget _reasons() => Padding(
    padding: const EdgeInsets.all(12),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('ממצאים:', style: TextStyle(color:Colors.grey[400], fontSize:11)),
      const SizedBox(height:4),
      ...app.suspicionReasons.map((r) => Padding(
        padding: const EdgeInsets.only(top:2),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('• ', style: TextStyle(color:Colors.grey, fontSize:12)),
          Expanded(child: Text(r, style: const TextStyle(color:Colors.grey, fontSize:12))),
        ]),
      )),
    ]),
  );

  Widget _actions() => Padding(
    padding: const EdgeInsets.fromLTRB(12,0,12,12),
    child: Row(children: [
      Expanded(child: OutlinedButton.icon(
        onPressed: onDelete,
        icon: const Icon(Icons.delete_forever, size:16, color:Colors.red),
        label: const Text('מחק דרך הגדרות', style: TextStyle(fontSize:12, color:Colors.red)),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: Colors.red.withOpacity(0.4)),
          padding: const EdgeInsets.symmetric(vertical:8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      )),
      const SizedBox(width:8),
      Expanded(child: ElevatedButton.icon(
        onPressed: onOpenStore,
        icon: const Icon(Icons.store, size:16),
        label: const Text('פתח בחנות', style: TextStyle(fontSize:12)),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF6C63FF),
          padding: const EdgeInsets.symmetric(vertical:8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      )),
    ]),
  );
}
