enum SuspicionLevel { clean, low, medium, high, critical }

class MonitoredApp {
  final String packageName;
  final String appName;
  final double iconMatchScore;
  final SuspicionLevel suspicionLevel;
  final List<String> suspicionReasons;
  final bool isRunningInBackground;

  MonitoredApp({
    required this.packageName,
    required this.appName,
    required this.iconMatchScore,
    required this.suspicionLevel,
    required this.suspicionReasons,
    required this.isRunningInBackground,
  });

  bool get hasIconMismatch => iconMatchScore < 0.7;

  String get suspicionText {
    switch (suspicionLevel) {
      case SuspicionLevel.clean: return 'נקי';
      case SuspicionLevel.low: return 'חשד נמוך';
      case SuspicionLevel.medium: return 'חשד בינוני';
      case SuspicionLevel.high: return 'חשד גבוה';
      case SuspicionLevel.critical: return 'חשד קריטי';
    }
  }

  Color get suspicionColor {
    switch (suspicionLevel) {
      case SuspicionLevel.clean: return const Color(0xFF4CAF50);
      case SuspicionLevel.low: return const Color(0xFF8BC34A);
      case SuspicionLevel.medium: return const Color(0xFFFF9800);
      case SuspicionLevel.high: return const Color(0xFFF44336);
      case SuspicionLevel.critical: return const Color(0xFF9C27B0);
    }
  }
}
