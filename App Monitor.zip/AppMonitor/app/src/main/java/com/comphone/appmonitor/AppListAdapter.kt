package com.comphone.appmonitor

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.comphone.appmonitor.databinding.ItemAppBinding // ייבוא ה-Binding Class

class AppListAdapter : ListAdapter<AppInfo, AppListAdapter.AppViewHolder>(AppDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val appInfo = getItem(position)
        holder.bind(appInfo)
    }

    class AppViewHolder(private val binding: ItemAppBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(appInfo: AppInfo) {
            binding.appNameTextView.text = appInfo.appName
            binding.packageNameTextView.text = appInfo.packageName
            binding.appIconImageView.setImageDrawable(appInfo.icon)

            // הגדרת צבע הרקע בהתאם לרמת החשד
            val context = binding.root.context
            val backgroundColor = when (appInfo.suspicionLevel) {
                SuspectLevel.NORMAL -> ContextCompat.getColor(context, android.R.color.white) // לבן
                SuspectLevel.MEDIUM -> ContextCompat.getColor(context, android.R.color.holo_orange_light) // צהוב-כתום
                SuspectLevel.HIGH -> ContextCompat.getColor(context, android.R.color.holo_red_light) // אדום
            }
            binding.appCardView.setCardBackgroundColor(backgroundColor)


            // טיפול בלחיצות על הכפתורים
            binding.appDetailsButton.setOnClickListener {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", appInfo.packageName, null)
                intent.data = uri
                context.startActivity(intent)
            }

            binding.openInStoreButton.setOnClickListener {
                try {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appInfo.packageName)))
                } catch (e: ActivityNotFoundException) {
                    // אם חנות Play לא זמינה, פתח בדפדפן
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appInfo.packageName)))
                }
            }
        }
    }

    private class AppDiffCallback : DiffUtil.ItemCallback<AppInfo>() {
        override fun areItemsTheSame(oldItem: AppInfo, newItem: AppInfo): Boolean {
            return oldItem.packageName == newItem.packageName
        }

        override fun areContentsTheSame(oldItem: AppInfo, newItem: AppInfo): Boolean {
            return oldItem == newItem // Data class equals compares all properties
        }
    }
}