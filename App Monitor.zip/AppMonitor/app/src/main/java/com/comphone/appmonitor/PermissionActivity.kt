package com.comphone.appmonitor // ודא שזהו שם החבילה הנכון שלך

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.comphone.appmonitor.databinding.ActivityPermissionBinding // ייבוא ה-Binding Class

class PermissionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.grantPermissionButton.setOnClickListener {
            // נווט למסך הגדרות גישה לנתוני שימוש
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        binding.continueButton.setOnClickListener {
            // חזור ל-MainActivity
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish() // סיים את ה-PermissionActivity
        }
    }

    override fun onResume() {
        super.onResume()
        // בדוק את סטטוס ההרשאה בכל פעם שה-Activity חוזר לחזית
        updatePermissionStatus()
    }

    private fun updatePermissionStatus() {
        if (hasUsageStatsPermission()) {
            binding.permissionStatusTextView.text = "סטטוס הרשאה: אושר"
            binding.permissionStatusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
            binding.continueButton.isEnabled = true
            binding.grantPermissionButton.isEnabled = false // נטרל את כפתור ההרשאה כשהיא כבר קיימת
        } else {
            binding.permissionStatusTextView.text = "סטטוס הרשאה: טרם אושר"
            binding.permissionStatusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
            binding.continueButton.isEnabled = false
            binding.grantPermissionButton.isEnabled = true
        }
    }

    // פונקציה זהה לזו שב-MainActivity לבדיקת הרשאת "גישה לנתוני שימוש"
    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}