package com.comphone.appmonitor

enum class SuspectLevel {
    NORMAL,  // לבן: פעילות תקינה
    MEDIUM,  // צהוב: חשד בינוני
    HIGH     // אדום: חשד גבוה
}