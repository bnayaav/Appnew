package com.comphone.appmonitor

import android.graphics.drawable.Drawable
import java.io.Serializable // <-- ADD THIS IMPORT

data class AppInfo(
    val appName: String,
    val packageName: String,
    // Note: Drawable is not directly Serializable/Parcelable.
    // If you need to serialize Drawables, you'll need a custom solution
    // (e.g., converting to Bitmap and then to byte array, or storing icon resource ID).
    // For now, let's keep it as is, but be aware it might cause issues during actual serialization.
    // A better approach for icons might be to send the packageName and retrieve the icon in MainActivity.
    val icon: Drawable?,
    val detectionTime: Long,
    val suspicionLevel: SuspectLevel,
    val isFromPlayStore: Boolean,
    val iconMatch: Boolean
) : Serializable // <-- ADD THIS INTERFACE IMPLEMENTATION