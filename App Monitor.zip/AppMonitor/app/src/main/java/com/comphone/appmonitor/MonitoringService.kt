package com.comphone.appmonitor

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager // לייבוא LocalBroadcastManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MonitoringService : Service() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    private lateinit var usageStatsManager: UsageStatsManager
    private lateinit var packageManager: PackageManager

    // רשימה של אפליקציות ידועות להתעלמות (ניתן להרחיב)
    private val appBlacklist = listOf(
        "com.android.systemui", // System UI
        "com.google.android.apps.nexuslauncher", // Google Launcher
        "com.google.android.gms", // Google Play Services
        "com.google.android.googlequicksearchbox", // Google Search
        "com.whatsapp",
        "com.waze",
        "com.facebook.katana",
        "com.instagram.android",
        "com.google.android.youtube",
        "com.android.chrome",
        "com.google.android.apps.photos",
        "com.google.android.dialer",
        "com.google.android.apps.maps",
        "com.android.settings", // Settings app
        // הוסף כאן עוד שמות חבילה של אפליקציות מוכרות ולגיטימיות
    )

    // משתנה לשמירת האפליקציה האחרונה שזוהתה כדי למנוע כפילויות
    private var lastForegroundPackage: String? = null

    companion object {
        const val CHANNEL_ID = "AppMonitorChannel"
        const val NOTIFICATION_ID = 1
        const val ACTION_APP_DETECTED = "com.comphone.appmonitor.APP_DETECTED"
        const val EXTRA_APP_INFO = "extra_app_info"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        packageManager = applicationContext.packageManager
        Log.d("MonitoringService", "Service onCreate called. Managers initialized.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("MonitoringService", "Service onStartCommand called.")
        val notification = createNotification()
        startForeground(NOTIFICATION_ID, notification)

        serviceScope.launch {
            while (isActive) {
                checkForForegroundApp() // קריאה לפונקציה החדשה
                delay(1000) // בדיקה כל שנייה
            }
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        Log.d("MonitoringService", "Monitoring service onDestroy called. Coroutines cancelled.")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "App Monitor Service Channel",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }

    private fun createNotification(): android.app.Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("מנטר אפליקציות פעיל")
            .setContentText("מנטר את פעילות האפליקציות ברקע...")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    // *** לוגיקת זיהוי האפליקציות ***
    private fun checkForForegroundApp() {
        val time = System.currentTimeMillis()
        val usageEvents = usageStatsManager.queryEvents(time - 1000 * 5, time) // חפש אירועים בחמש השניות האחרונות
        val event = UsageEvents.Event()
        var currentForegroundPackage: String? = null

        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            // נחפש את ה-ACTIVITY_RESUMED האחרון, שמציין שהאפליקציה עלתה לחזית
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {                currentForegroundPackage = event.packageName
            }
        }

        currentForegroundPackage?.let { packageName ->
            if (packageName != lastForegroundPackage) { // רק אם זו אפליקציה חדשה בחזית
                lastForegroundPackage = packageName
                Log.d("MonitoringService", "New foreground app: $packageName")
                processDetectedApp(packageName)
            }
        }
    }

    private fun processDetectedApp(packageName: String) {
        try {
            val applicationInfo = packageManager.getApplicationInfo(packageName, 0)
            val appName = packageManager.getApplicationLabel(applicationInfo).toString()
            val appIcon = packageManager.getApplicationIcon(applicationInfo)
            val detectionTime = System.currentTimeMillis()

            // סינון אפליקציות מערכת ואפליקציות ב-blacklist
            if (isSystemApp(applicationInfo) || appBlacklist.contains(packageName)) {
                Log.d("MonitoringService", "Ignoring system/blacklisted app: $appName")
                return
            }

            // בדיקת מקור התקנה (האם מחנות Play)
            val isFromPlayStore = isAppInstalledFromPlayStore(packageName)

            // בדיקת התאמת אייקונים (זוהי בדיקה מורכבת ומופשטת)
            // במציאות, השוואת אייקונים דורשת לוגיקה מורכבת יותר (hash, השוואת ביטים)
            // לצורך הדוגמה, נניח True
            val iconMatch = true // Placeholder for actual icon comparison logic

            // חישוב רמת חשד
            val suspicionLevel = calculateSuspicionLevel(isFromPlayStore, iconMatch)

            val detectedApp = AppInfo(
                appName = appName,
                packageName = packageName,
                icon = appIcon,
                detectionTime = detectionTime,
                suspicionLevel = suspicionLevel,
                isFromPlayStore = isFromPlayStore,
                iconMatch = iconMatch
            )

            // שלח את הנתונים ל-MainActivity
            sendAppInfoToMainActivity(detectedApp)

        } catch (e: PackageManager.NameNotFoundException) {
            Log.e("MonitoringService", "App not found: $packageName", e)
        } catch (e: Exception) {
            Log.e("MonitoringService", "Error processing app: $packageName", e)
        }
    }

    private fun isSystemApp(appInfo: ApplicationInfo): Boolean {
        return (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
    }

    private fun isAppInstalledFromPlayStore(packageName: String): Boolean {
        val installerPackageName = packageManager.getInstallerPackageName(packageName)
        return installerPackageName != null && installerPackageName == "com.android.vending"
    }

    // פונקציה פשוטה לחישוב רמת חשד
    private fun calculateSuspicionLevel(isFromPlayStore: Boolean, iconMatch: Boolean): SuspectLevel {
        if (!isFromPlayStore || !iconMatch) {
            return SuspectLevel.HIGH
        }
        // ניתן להוסיף לוגיקה מורכבת יותר עבור SuspectLevel.MEDIUM
        return SuspectLevel.NORMAL
    }

    // *** שליחת נתונים ל-MainActivity באמצעות LocalBroadcastManager ***
    private fun sendAppInfoToMainActivity(appInfo: AppInfo) {
        val intent = Intent(ACTION_APP_DETECTED).apply {
            putExtra(EXTRA_APP_INFO, appInfo)
        }
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
        Log.d("MonitoringService", "Sent app info for: ${appInfo.appName} (Suspicion: ${appInfo.suspicionLevel})")
    }
}